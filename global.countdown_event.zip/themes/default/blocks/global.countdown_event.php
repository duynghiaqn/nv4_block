<?php

/**
 * @Project NUKEVIET 4.x
 * @Author DANGDINHTU (dlinhvan@gmail.com)
 * @Copyright (C) 2016 Nuke.vn All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Fri, 05/08/2016 18:00 GMT
 */

if( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

if( ! nv_function_exists( 'nukevn_countdown_event' ) )
{
	function nukevn_countdown_event_config( $module, $data_block, $lang_block )
	{
		global $global_config;

		if( defined( 'NV_EDITOR' ) )
		{
			require NV_ROOTDIR . '/' . NV_EDITORSDIR . '/' . NV_EDITOR . '/nv.php';
		}

		$event = htmlspecialchars( nv_editor_br2nl( $data_block['event'] ) );
		if( defined( 'NV_EDITOR' ) and nv_function_exists( 'nv_aleditor' ) )
		{
			$event = nv_aleditor( 'config_event', '100%', '150px', $event );
		}
		else
		{
			$event = '<textarea style="width: 100%" name="config_event" id="config_event" cols="20" rows="8">' . $event . '</textarea>';
		}

		$html = '';
		$html .= '<tr>';
		$html .= '	<td>' . $lang_block['gettime'] . '</td>';
		$html .= '	<td>';
		$html .= '		<input type="text" class="form-control" id="config_gettime" name="config_gettime" value="' . $data_block['gettime'] . '" max-length="10" style="width:100px;display:inline-block" readonly="readonly"/>';
		$html .= '		<select class="form-control" name="config_gethour" style="width:80px;display:inline-block">';
		for( $i = 0; $i <= 23; ++$i )
		{
			$html .= '			<option value="' . $i . '" ' . ( ( $i == $data_block['gethour'] ) ? ' selected="selected"' : '' ) . ' >' . str_pad( $i, 2, '0', STR_PAD_LEFT ) . '</option>';
		}
		$html .= '		</select>';
		$html .= '		<select class="form-control" name="config_getminutes" style="width:80px;display:inline-block">';
		for( $i = 0; $i <= 59; ++$i )
		{
			$html .= '			<option value="' . $i . '" ' . ( ( $i == $data_block['getminutes'] ) ? ' selected="selected"' : '' ) . ' >' . str_pad( $i, 2, '0', STR_PAD_LEFT ) . '</option>';
		}
		$html .= '		</select>';
		$html .= '		<select class="form-control" name="config_getseconds" style="width:80px;display:inline-block">';
		for( $i = 1; $i <= 60; ++$i )
		{
			$html .= '			<option value="' . $i . '" ' . ( ( $i == $data_block['getseconds'] ) ? ' selected="selected"' : '' ) . ' >' . str_pad( $i, 2, '0', STR_PAD_LEFT ) . '</option>';
		}
		$html .= '		</select>';
		$html .= '	</td>';
		$html .= '</tr>';

		$html .= '<tr>';
		$html .= '	<td>' . $lang_block['event'] . '</td>';
		$html .= '	<td>' . $event . '</td>';
		$html .= '</tr>';
		$html .= '<script type="text/javascript">';
		$html .= '$(document).ready(function() {';
		$html .= '	$("#config_gettime").datepicker({';
		$html .= '		showOn : "both",';
		$html .= '		dateFormat : "dd/mm/yy",';
		$html .= '		changeMonth : true,';
		$html .= '		changeYear : true,';
		$html .= '		showOtherMonths : true,';
		$html .= '		buttonImage : nv_base_siteurl + "assets/images/calendar.gif",';
		$html .= '		buttonImageOnly : true';
		$html .= '	});';
		$html .= '});';
		$html .= '</script>';

		return $html;
	}

	function nukevn_countdown_event_config_submit( $module, $lang_block )
	{
		global $nv_Request;

		$event = $nv_Request->get_editor( 'config_event', '', NV_ALLOWED_HTML_TAGS );
		$event = strtr( $event, array(
			"\r\n" => '',
			"\r" => '',
			"\n" => '' ) );

		$return = array();
		$return['error'] = array();
		$return['config']['gettime'] = $nv_Request->get_string( 'config_gettime', 'post', '' );
		$return['config']['gethour'] = $nv_Request->get_int( 'config_gethour', 'post', 0 );
		$return['config']['getminutes'] = $nv_Request->get_int( 'config_getminutes', 'post', 0 );
		$return['config']['getseconds'] = $nv_Request->get_int( 'config_getseconds', 'post', 0 );
		$return['config']['event'] = $event;

		return $return;
	}
	function nukevn_countdown_event( $block_config )
	{
		global $module_info, $global_config;

		if( file_exists( NV_ROOTDIR . '/themes/' . $module_info['template'] . '/blocks/global.countdown_event.tpl' ) )
		{
			$block_theme = $module_info['template'];
		}
		else
		{
			$block_theme = 'default';
		}

		$xtpl = new XTemplate( 'global.countdown_event.tpl', NV_ROOTDIR . '/themes/' . $block_theme . '/blocks' );
		$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
		$xtpl->assign( 'TEMPLATE', $block_theme );

		if( preg_match( '/^([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{4})$/', $block_config['gettime'], $m ) )
		{
			$month = $m[2];
			$day = $m[1];
			$year = $m[3];

		}
		else
		{

			return;
		}
		$hour = $block_config['gethour'];
		$minute = $block_config['getminutes'];
		$second = $block_config['getseconds'];

		$current_year = date( 'Y', NV_CURRENTTIME );
		$current_month = date( 'm', NV_CURRENTTIME );
		$current_day = date( 'd', NV_CURRENTTIME );
		$current_hour = date( 'H', NV_CURRENTTIME );
		$current_minute = date( 'i', NV_CURRENTTIME );
		$current_second = date( 's', NV_CURRENTTIME );

		$time_receive = mktime( $hour, $minute, $second, $month, $day, $year );
		$beetween = ( $time_receive - NV_CURRENTTIME );
		if( $beetween > 0 )
		{
			$rest_day = $beetween % 86400;
			$rest_hour = $rest_day % 3600;
			$rest_minute = $rest_hour % 60;
			$count_day = intval( $beetween / 86400 );
			$count_hour = intval( $rest_day / 3600 );
			$count_minute = intval( $rest_hour / 60 );
			$count_second = $rest_minute;

			$xtpl->assign( 'TIME', date( 'Y/m/d H:i:s', $time_receive ) );
			$xtpl->assign( 'GIAY', str_pad( $count_second, 2, 0, STR_PAD_LEFT ) );
			$xtpl->assign( 'PHUT', str_pad( $count_minute, 2, 0, STR_PAD_LEFT ) );
			$xtpl->assign( 'GIO', str_pad( $count_hour, 2, 0, STR_PAD_LEFT ) );
			$xtpl->assign( 'NGAY', str_pad( $count_day, 2, 0, STR_PAD_LEFT ) );
			$xtpl->assign( 'RELOAD', 0 );

			$xtpl->parse( 'main.load_script' );

		}
		else
		{
			$xtpl->assign( 'TIME', date( 'Y/m/d H:i:s', $time_receive ) );
			$xtpl->assign( 'GIAY', '00' );
			$xtpl->assign( 'PHUT', '00' );
			$xtpl->assign( 'GIO', '00' );
			$xtpl->assign( 'NGAY', '00' );
			$xtpl->assign( 'RELOAD', 1 );

		}
		$xtpl->assign( 'DATA', $block_config );
		$xtpl->parse( 'main' );

		return $xtpl->text( 'main' );

	}
}

if( defined( 'NV_SYSTEM' ) )
{
	$content = nukevn_countdown_event( $block_config );
}
