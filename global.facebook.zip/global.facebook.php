<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2014 VINADES ., JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Jan 17, 2011 11:34:27 AM
 */

if (! defined('NV_MAINFILE')) {
    die('Stop!!!');
}

if (! nv_function_exists('facebook_page')) {
    function facebook_page_config()
    {
        global $lang_global, $data_block;

        $html = '<tr>';
        $html .= '<td>Đường dẫn page </td>';
        $html .= '<td><input type="text" name="url" value="' . nv_htmlspecialchars($data_block['url']) . '" size="80"></td>';
        $html .= '</tr>';
        $html .= '<tr>';
        $html .= '<td>Chiều cao</td>';
        $html .= '<td><input type="text" name="height" value="' . nv_htmlspecialchars($data_block['height']) . '" size="80">px</td>';
        $html .= '</tr>';
       

        return $html;
    }

    function facebook_page_submit()
    {
        global $nv_Request;

        $return = array();
        $return['error'] = array();
        $return['config']['url'] = $nv_Request->get_title('url', 'post');
        $return['config']['height'] = $nv_Request->get_title('height', 'post');
    
        return $return;
    }

    /**
     * nv_menu_theme_default_footer()
     *
     * @param mixed $block_config
     * @return
     */
    function facebook_page($block_config)
    {
        global $global_config, $lang_global;

        if (file_exists(NV_ROOTDIR . '/themes/' . $global_config['module_theme'] . '/blocks/global.facebook.tpl')) {
            $block_theme = $global_config['module_theme'];
        } elseif (file_exists(NV_ROOTDIR . '/themes/' . $global_config['site_theme'] . '/blocks/global.facebook.tpl')) {
            $block_theme = $global_config['site_theme'];
        } else {
            $block_theme = 'default';
        }

        $xtpl = new XTemplate('global.facebook.tpl', NV_ROOTDIR . '/themes/' . $block_theme . '/blocks');
        $xtpl->assign('LANG', $lang_global);
        $xtpl->assign('DATA', $block_config);
        $xtpl->parse('main');
        return $xtpl->text('main');
    }
}

if (defined('NV_SYSTEM')) {
    $content = facebook_page($block_config);
}
